public class Manager extends Empleado2 {
    private String redsocial;
    private String apps;
    private int  horas;

    public Manager(){
        super();
    }

    public Manager(String nombre, double salario, String cargo, String redsocial, String apps, int horas){
        super(nombre, salario,cargo);
        this.redsocial = redsocial;
        this.apps = apps;
        this.horas = horas;
    }


public String getRedsocial() {
    return redsocial;
}
public String getApps() {
    return apps;
}
public int getHoras() {
    return horas;
}
public void setRedsocial(String redsocial){
    this.redsocial = redsocial;
}
public void setApps(String apps){
    this.apps = apps;
}
public void setHoras(int horas){
    this.horas = horas;
}
@Override
public void mostrarInfo() {
        System.out.println("Red social: " + redsocial);
        System.out.println("Apps: " + apps);
        System.out.println("horas: " + horas);
    }
}
