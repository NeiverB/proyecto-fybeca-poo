public class Diseñadorweb extends Empleado2{
    private String herramienta;
    private String sitios;
    private String dominios;

    public Diseñadorweb(){
        super();
    }

    public Diseñadorweb(String nombre, double salario, String cargo, String herramienta, String sitios, String dominio){
        super(nombre, salario,cargo);
        this.herramienta=herramienta;
        this.sitios=sitios;
        this.dominios=dominio;

    }

    public String GetHerramienta(){
        return herramienta;
    }
    public void setHerramienta(String herramienta){
        this.herramienta = herramienta;
    }
}